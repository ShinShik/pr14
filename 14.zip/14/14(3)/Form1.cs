﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _14_1_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBoxN_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttonStart_Click(object sender, EventArgs e)
        {
            Queue<int> MyQueue = new Queue<int>();
            int n, countqueue;
            string ItemsInsStack = "";
            try
            {
                n = int.Parse(textBoxN.Text);
                for (int i = 1; i < n+1; i++)
                {
                    MyQueue.Enqueue(i);
                }
                countqueue = MyQueue.Count;
                foreach (int i in MyQueue)
                {
                    ItemsInsStack += $"{i}, ";
                }                
                MyQueue.Clear();
                string unsw = $"n = {n}\n" +
                    $"Размерность Queue = {countqueue}\n" +
                    $"Верхний элемент Queue = {n}\n" +
                    $"Элементы Queue {ItemsInsStack}\n" +
                    $"Новая размерность Queue {MyQueue.Count}";
                MessageBox.Show(unsw);
            }
            catch { MessageBox.Show("Вы ввели некорректное значение"); }
            
        }
    }
}
