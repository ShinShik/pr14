﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _14_1_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBoxN_TextChanged(object sender, EventArgs e)
        {
        }

        private void buttonStart_Click(object sender, EventArgs e)
        {
            Stack<int> MyStack = new Stack<int>();
            int n, countstack;
            string ItemsInsStack = "";
            try
            {
                n = int.Parse(textBoxN.Text);
                for (int i = 1; i < n+1; i++)
                {
                    MyStack.Push(i);
                }
                countstack = MyStack.Count;
                foreach (int i in MyStack)
                {
                    ItemsInsStack += $"{i}, ";
                }                
                MyStack.Clear();
                string unsw = $"n = {n}\n" +
                    $"Размерность стека = {countstack}\n" +
                    $"Верхний элемент стека = {n}\n" +
                    $"Элементы стэка {ItemsInsStack}\n" +
                    $"Новая размерность стэка {MyStack.Count}";
                MessageBox.Show(unsw);
            }
            catch { MessageBox.Show("Вы ввели некорректное значение"); }
            
        }
    }
}
