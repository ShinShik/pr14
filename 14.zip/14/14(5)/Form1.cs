﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Xml.Linq;

namespace _14_4_
{  
    public partial class Form1 : Form
    {
        List<string> people = new List<string>();
        Queue<People> peoples = new Queue<People>();
        public Form1()
        {
            InitializeComponent();
            
        }

        private void buttonStart_Click(object sender, EventArgs e)
        {            
            listBoxSort.Items.Clear();
            listBoxNotSort.Items.Clear();
            if (File.Exists(@"txt.txt"))
            {
                StreamReader sr = File.OpenText("txt.txt");
                while (!sr.EndOfStream)
                {
                    string[] line = sr.ReadLine().Split();
                    People name = new People(line[0], line[1], line[2], int.Parse(line[3]), int.Parse(line[4]));
                    peoples.Enqueue(name);
                }
                sr.Close();
                foreach (People x in peoples)
                {
                    listBoxNotSort.Items.Add($"{x.name} {x.surname} {x.FatherName} {x.years} {x.wes}");
                }
                var p = from people in peoples
                        where people.years < 40
                        orderby people.name
                        select people;
                
                foreach (People x in p)
                {
                    listBoxSort.Items.Add($"{x.name} {x.surname} {x.FatherName} {x.years} {x.wes}");
                }
                p = from people in peoples
                    where people.years >= 40 
                    orderby people.name
                    select people;                
                foreach (People x in p)
                {
                    listBoxSort.Items.Add($"{x.name} {x.surname} {x.FatherName} {x.years} {x.wes}");
                }
            }
        }

        private void listBoxSort_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listBoxNotSort_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
