﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _14_4_
{
    public class People
    {
        public string name, surname, FatherName;
        public int years, wes;
        public People(string name, string surname, string FatherName, int years, int wes)
        {
            this.name = name;
            this.surname = surname;
            this.FatherName = FatherName;
            this.years = years;
            this.wes = wes;
        }
    }
}
